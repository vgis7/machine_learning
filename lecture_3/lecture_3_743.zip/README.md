# Solution for the lecture 3 assignements

It is recommended to run this from a virtual environment called .venv/. The required packages are frozen in requirements.txt

To get going quickly:

```bash
python3 -m venv .venv
source .venv/bin/activate 
pip install -r requirements.txt
```

